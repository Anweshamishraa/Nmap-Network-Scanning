# 6. Snort IDS

> **Status:** Methodology documented. Lab not yet run on my setup — screenshots to be added here once I complete it (`images/` folder is ready).
> Perform this only against systems/VMs you own or are explicitly authorized to test.

## Sub-tasks
- [ ] Install
- [ ] Configure
- [ ] Custom Rules
- [ ] ICMP
- [ ] Port Scan
- [ ] SSH Brute Force
- [ ] Alerts

## Methodology
Install Snort, configure snort.conf (HOME_NET, rule paths), write custom rules to detect ICMP pings, Nmap port scans, and SSH brute-force attempts, run Snort in IDS mode (`snort -A console -c snort.conf -i eth0`), generate the traffic from an attacker VM, and capture the resulting alerts.

## How to complete this folder
1. Run through each sub-task above in your lab.
2. Save a screenshot for each step into `images/` (e.g. `01-install.png`, `02-configure.png`, ...).
3. Replace this note with a step-by-step write-up like `01-network-scanning-nmap/README.md`, embedding each screenshot with `![..](images/..png)` and a short explanation underneath.
