# 9. Splunk Log Analysis

> **Status:** Methodology documented. Lab not yet run on my setup — screenshots to be added here once I complete it (`images/` folder is ready).
> Perform this only against systems/VMs you own or are explicitly authorized to test.

## Sub-tasks
- [ ] Install
- [ ] Add Data
- [ ] SPL
- [ ] Failed Logins
- [ ] Brute Force
- [ ] Dashboards
- [ ] Alerts

## Methodology
Install Splunk Free, add a data source (e.g. auth.log / Windows Security log), write SPL queries to find failed login events, correlate repeated failures from one source into a brute-force detection, build a dashboard panel visualising login activity over time, and configure an alert that fires above a failed-login threshold.

## How to complete this folder
1. Run through each sub-task above in your lab.
2. Save a screenshot for each step into `images/` (e.g. `01-install.png`, `02-configure.png`, ...).
3. Replace this note with a step-by-step write-up like `01-network-scanning-nmap/README.md`, embedding each screenshot with `![..](images/..png)` and a short explanation underneath.
