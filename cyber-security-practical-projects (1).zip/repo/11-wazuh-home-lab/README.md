# 11. Wazuh Home Lab

> **Status:** Methodology documented. Lab not yet run on my setup — screenshots to be added here once I complete it (`images/` folder is ready).
> Perform this only against systems/VMs you own or are explicitly authorized to test.

## Sub-tasks
- [ ] Server
- [ ] Linux/Windows Agents
- [ ] FIM
- [ ] Vulnerability Detection
- [ ] Rootcheck
- [ ] MITRE ATT&CK
- [ ] Active Response

## Methodology
Deploy a Wazuh manager/server, enroll Linux and Windows agents, enable File Integrity Monitoring (FIM) on sensitive paths, enable the vulnerability detection module, run a Rootcheck scan, map resulting alerts to MITRE ATT&CK techniques in the dashboard, and configure an Active Response rule (e.g. auto-block an IP after repeated failed SSH logins).

## How to complete this folder
1. Run through each sub-task above in your lab.
2. Save a screenshot for each step into `images/` (e.g. `01-install.png`, `02-configure.png`, ...).
3. Replace this note with a step-by-step write-up like `01-network-scanning-nmap/README.md`, embedding each screenshot with `![..](images/..png)` and a short explanation underneath.
