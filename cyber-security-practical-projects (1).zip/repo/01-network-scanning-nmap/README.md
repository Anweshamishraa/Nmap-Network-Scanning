# 1. Network Scanning using Nmap

**Target:** `192.168.204.129` (Metasploitable 2 — intentionally vulnerable lab VM)
**Attacker machine:** Kali Linux
**Tool:** Nmap 7.99

> ⚠️ Lab/educational use only. All scanning was performed against a VM I own and control on an isolated local network, never against a host without authorization.

## Objective
Perform a complete reconnaissance sweep of a target host using Nmap — from checking if the host is alive, to full port/service enumeration, OS fingerprinting, vulnerability script scanning, and firewall/filtering detection.

---

## 1.1 Host Discovery
Before scanning ports, sweep the whole subnet to see which hosts are alive, then confirm the specific target responds.

```bash
nmap -sn 192.168.204.0/24
```

![Host Discovery - Nmap ping sweep](images/01a-host-discovery-nmap-sn.png)

**Explanation:** `-sn` tells Nmap to skip port scanning and only do host discovery (a "ping sweep") across the entire `/24` subnet. Out of 256 possible IPs, **4 hosts responded as up** (`.1`, `.2`, `.254`, `.128`), each with its MAC address and vendor (VMware) resolved via ARP — confirming the target `192.168.204.128` is live on the network before any port scanning begins.

```bash
ping 192.168.204.129
```

![Host Discovery - ping confirm](images/01b-host-discovery-ping-confirm.png)

**Explanation:** As a secondary check, a direct ICMP ping confirms the target responds with `ttl=64` (Linux default TTL; Windows is usually 128) and sub-5ms latency, confirming it's reachable on the local subnet.

---

## 1.2 Port Scanning
Scan the target for open TCP ports.

```bash
nmap 192.168.204.129
```

![Port Scanning](images/02-port-scanning.png)

**Explanation:** Nmap's default scan checks the top 1000 TCP ports. 23 ports came back **open**, including classic high-risk Metasploitable services: FTP (21), Telnet (23), SMTP (25), NetBIOS/SMB (139/445), MySQL (3306), PostgreSQL (5432), VNC (5900), and more — a very large attack surface for a single host.

---

## 1.3 Service & Version Detection + Full Scan Report
Combine service/version detection with OS detection and save everything to a report file.

```bash
nmap -sV -O -oN nmap_scan_report.txt 192.168.204.129
cat nmap_scan_report.txt
```

![Scan Report](images/03-service-version-scan-report.png)

**Explanation:**
- `-sV` probes each open port to identify the exact service and version (e.g. `vsftpd 2.3.4`, `OpenSSH 4.7p1 Debian 8ubuntu1`, `Apache httpd 2.2.8 (Ubuntu) DAV/2`).
- `-oN` saves the full report to a text file for documentation/reporting.
- Several versions here are **known-vulnerable** — most notably `vsftpd 2.3.4`, which has a public backdoor (CVE-2011-2523), confirmed later in the NSE script scan.

---

## 1.4 OS Detection
Fingerprint the target's operating system from TCP/IP stack behaviour.

```bash
nmap -O 192.168.204.129
```

![OS Detection](images/04-os-detection.png)

**Explanation:** Nmap identified the host as **Linux 2.6.9 – 2.6.33**, consistent with Metasploitable 2, which ships an old Ubuntu 8.04 kernel. OS detection uses TCP sequence prediction, TTL values, window sizes and other stack quirks to fingerprint the OS without needing login access.

---

## 1.5 NSE Script Scanning (Vulnerability Scripts)
Run Nmap's scripting engine with the `vuln` category to automatically check for known vulnerabilities.

```bash
nmap --script vuln 192.168.204.129
```

![NSE Script Scanning](images/05-nse-script-scanning.png)

**Explanation:** The NSE `vuln` scripts flagged real, exploitable issues on this host:
- **`ftp-vsftpd-backdoor`** — confirms vsftpd 2.3.4's backdoor is exploitable; the script even shows command execution returning `uid=0(root) gid=0(root)` — i.e. instant root.
- **`ssl-poodle`** — SMTP's SSL config is vulnerable to the POODLE padding-oracle attack (CVE-2014-3566).

This step turns a plain port list into an actionable vulnerability report.

---

## 1.6 Firewall Detection
Use an ACK scan to determine whether a stateful firewall is filtering traffic to the target.

```bash
nmap -sA 192.168.204.129
```

![Firewall Detection](images/06-firewall-detection.png)

**Explanation:** An ACK scan doesn't report open/closed ports — it reports **filtered vs unfiltered**. Here, all 1000 scanned ports came back `unfiltered`, meaning there is **no stateful firewall** between the attacker and the target dropping/filtering the ACK packets. This matches a default, un-firewalled Metasploitable VM.

---

## Summary

| Step | Command | Key Finding |
|---|---|---|
| Host Discovery | `ping` | Host is up, Linux (TTL 64) |
| Port Scanning | `nmap <target>` | 23 open ports |
| Service/Version + Report | `nmap -sV -O -oN report.txt` | vsftpd 2.3.4, OpenSSH 4.7p1, Apache 2.2.8, etc. |
| OS Detection | `nmap -O` | Linux 2.6.9–2.6.33 |
| NSE Vuln Scan | `nmap --script vuln` | vsftpd backdoor (root shell), SSL POODLE |
| Firewall Detection | `nmap -sA` | No filtering/firewall present |

**Conclusion:** The target exposes a large number of outdated, misconfigured services with at least one critical, trivially-exploitable backdoor (vsftpd 2.3.4) and no firewall filtering. This is intentional (Metasploitable is built to be vulnerable) but demonstrates exactly the kind of findings a real Nmap-based recon phase would surface in a penetration test.
