# How to upload this to GitHub

1. Go to github.com → **New repository** → name it e.g. `cyber-security-practical-projects` → create it **empty** (no README/license, we already have ours).
2. Unzip the folder you downloaded from this chat, open a terminal inside it, then run:

```bash
git init
git add .
git commit -m "Add Project 1: Network Scanning using Nmap + methodology for all other projects"
git branch -M main
git remote add origin https://github.com/<your-username>/cyber-security-practical-projects.git
git push -u origin main
```

3. As you complete each remaining project (Nessus, Metasploit, malware analysis, Snort, Wireshark, DVWA, Splunk, phishing analysis, Wazuh), add your real screenshots into that folder's `images/` subfolder, rewrite its `README.md` the same way `01-network-scanning-nmap/README.md` is written (embed each image + explanation), then:

```bash
git add .
git commit -m "Add Project X screenshots and write-up"
git push
```
