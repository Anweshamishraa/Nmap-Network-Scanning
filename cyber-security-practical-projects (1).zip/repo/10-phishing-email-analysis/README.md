# 10. Phishing Email Analysis

> **Status:** Methodology documented. Lab not yet run on my setup — screenshots to be added here once I complete it (`images/` folder is ready).
> Perform this only against systems/VMs you own or are explicitly authorized to test.

## Sub-tasks
- [ ] Headers
- [ ] SPF/DKIM/DMARC
- [ ] URLs
- [ ] Attachments
- [ ] IOCs
- [ ] Report

## Methodology
Take a sample phishing email (.eml), examine the full headers (Received chain, Return-Path, Reply-To spoofing), check SPF/DKIM/DMARC authentication results, extract and safely analyse embedded URLs (URL/IP reputation lookup, no clicking), check attachments by hash on VirusTotal without opening them, compile the IOCs (sender, URLs, hashes), and write up findings in a short incident report.

## How to complete this folder
1. Run through each sub-task above in your lab.
2. Save a screenshot for each step into `images/` (e.g. `01-install.png`, `02-configure.png`, ...).
3. Replace this note with a step-by-step write-up like `01-network-scanning-nmap/README.md`, embedding each screenshot with `![..](images/..png)` and a short explanation underneath.
