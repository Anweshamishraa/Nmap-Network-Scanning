# Cyber Security Practical Projects

Hands-on cybersecurity lab projects — network recon, vulnerability assessment, exploitation, malware analysis, IDS, web app pentesting, log analysis, phishing analysis, and SIEM/EDR home lab. All testing performed against VMs I own on an isolated lab network (primarily **Metasploitable 2** and **DVWA**) for educational purposes only.

## Projects

| # | Project | Status |
|---|---|---|
| 1 | [Network Scanning using Nmap](01-network-scanning-nmap/) | ✅ Complete |
| 2 | [Vulnerability Assessment using Nessus](02-vulnerability-assessment-nessus/) | 🔲 Methodology ready |
| 3 | [Bind & Reverse Shell using Metasploit](03-bind-reverse-shell-metasploit/) | 🔲 Methodology ready |
| 4 | [Static Malware Analysis](04-static-malware-analysis/) | 🔲 Methodology ready |
| 5 | [Dynamic Malware Analysis](05-dynamic-malware-analysis/) | 🔲 Methodology ready |
| 6 | [Snort IDS](06-snort-ids/) | 🔲 Methodology ready |
| 7 | [Wireshark Packet Analysis](07-wireshark-packet-analysis/) | 🔲 Methodology ready |
| 8 | [DVWA Web App Pentesting](08-dvwa-pentesting/) | 🔲 Methodology ready |
| 9 | [Splunk Log Analysis](09-splunk-log-analysis/) | 🔲 Methodology ready |
| 10 | [Phishing Email Analysis](10-phishing-email-analysis/) | 🔲 Methodology ready |
| 11 | [Wazuh Home Lab](11-wazuh-home-lab/) | 🔲 Methodology ready |

Only **Project 1** has real screenshots/evidence right now, so it's written up fully. Every other folder has its sub-tasks, tools, and step-by-step methodology already documented — as each lab is actually run, drop the screenshots into that project's `images/` folder and expand its README the same way Project 1's is written.

## Disclaimer
All activity shown in this repository was performed in a private, isolated lab environment against intentionally vulnerable systems I own (Metasploitable 2, DVWA, etc.). Nothing here should be used against systems you do not own or do not have explicit written authorization to test.
