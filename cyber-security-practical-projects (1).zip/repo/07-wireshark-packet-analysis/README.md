# 7. Wireshark Packet Analysis

> **Status:** Methodology documented. Lab not yet run on my setup — screenshots to be added here once I complete it (`images/` folder is ready).
> Perform this only against systems/VMs you own or are explicitly authorized to test.

## Sub-tasks
- [ ] Packet Capture
- [ ] TCP Handshake
- [ ] DNS
- [ ] HTTP/HTTPS
- [ ] ICMP
- [ ] FTP
- [ ] Attack Analysis

## Methodology
Capture live traffic with Wireshark, then filter and analyse: the TCP 3-way handshake (`tcp.flags.syn==1`), DNS queries/responses, HTTP/HTTPS requests, ICMP echo traffic, FTP login credentials sent in cleartext, and identify signs of an attack (e.g. a port scan's SYN flood pattern) in the capture.

## How to complete this folder
1. Run through each sub-task above in your lab.
2. Save a screenshot for each step into `images/` (e.g. `01-install.png`, `02-configure.png`, ...).
3. Replace this note with a step-by-step write-up like `01-network-scanning-nmap/README.md`, embedding each screenshot with `![..](images/..png)` and a short explanation underneath.
