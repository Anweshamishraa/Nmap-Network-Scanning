# 3. Bind & Reverse Shell using Metasploit

> **Status:** Methodology documented. Lab not yet run on my setup — screenshots to be added here once I complete it (`images/` folder is ready).
> Perform this only against systems/VMs you own or are explicitly authorized to test.

## Sub-tasks
- [ ] msfvenom Payload
- [ ] Multi/Handler
- [ ] Reverse TCP
- [ ] Bind TCP
- [ ] Meterpreter
- [ ] Post Exploitation

## Methodology
Generate a payload with msfvenom (e.g. windows/meterpreter/reverse_tcp or linux/x86/shell_bind_tcp), set up exploit/multi/handler in msfconsole to catch the connection, deliver/execute the payload on the target, obtain a Meterpreter/shell session, and perform basic post-exploitation (sysinfo, getuid, screenshot, file download).

## How to complete this folder
1. Run through each sub-task above in your lab.
2. Save a screenshot for each step into `images/` (e.g. `01-install.png`, `02-configure.png`, ...).
3. Replace this note with a step-by-step write-up like `01-network-scanning-nmap/README.md`, embedding each screenshot with `![..](images/..png)` and a short explanation underneath.
